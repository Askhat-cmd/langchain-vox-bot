import os
import logging
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
from langchain.text_splitter import MarkdownHeaderTextSplitter
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def recreate_embeddings():
    """
    Основная функция для создания и сохранения векторной базы данных.
    Читает пути из переменных окружения.
    """
    load_dotenv()
    logging.info("--- Начало процесса создания эмбеддингов ---")

    knowledge_base_path = os.getenv("KNOWLEDGE_BASE_PATH")
    persist_directory = os.getenv("PERSIST_DIRECTORY")

    if not knowledge_base_path or not persist_directory:
        logging.critical("КРИТИЧЕСКАЯ ОШИБКА: Переменные окружения KNOWLEDGE_BASE_PATH и PERSIST_DIRECTORY должны быть установлены.")
        return False

    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Абсолютные пути из .env или относительные от корня проекта
    source_document_path = os.path.join(script_dir, knowledge_base_path)
    db_directory = os.path.join(script_dir, persist_directory)


    logging.info(f"1/4: Загрузка документа из '{source_document_path}'...")
    if not os.path.exists(source_document_path):
        logging.error(f"Файл '{source_document_path}' не найден.")
        return False

    with open(source_document_path, 'r', encoding='utf-8') as f:
        markdown_document = f.read()
    logging.info("Документ успешно загружен.")

    headers_to_split_on = [
        ("##", "Header 2"),
        ("###", "Header 3"),
    ]

    logging.info("2/4: Разделение текста на чанки по заголовкам Markdown...")
    markdown_splitter = MarkdownHeaderTextSplitter(headers_to_split_on=headers_to_split_on)
    texts = markdown_splitter.split_text(markdown_document)
    logging.info(f"Текст разделен на {len(texts)} чанков.")

    logging.info("3/4: Инициализация модели эмбеддингов OpenAI...")
    embeddings = OpenAIEmbeddings(chunk_size=1000)
    logging.info("Модель инициализирована.")

    logging.info(f"4/4: Создание и сохранение векторной базы в папку '{db_directory}'...")
    db = Chroma.from_documents(
        texts,
        embeddings,
        persist_directory=db_directory
    )
    logging.info("--- Процесс успешно завершен! ---")
    logging.info(f"Ваша база знаний готова для использования в папке '{db_directory}'.")
    return True

def main_cli():
    """
    Функция для запуска из командной строки.
    """
    recreate_embeddings()

if __name__ == "__main__":
    main_cli()
